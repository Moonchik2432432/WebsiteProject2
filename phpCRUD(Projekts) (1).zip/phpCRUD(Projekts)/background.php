<div class="background">
    <div class="blur-layer"></div>
</div>